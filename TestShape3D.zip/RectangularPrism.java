public class RectangularPrism extends Box implements Shape3D{
	public double volume(){
		return length*width*height;
	}
	
	public String toString(){
		return "volume: " + volume() + " This is a prism";
	}
}