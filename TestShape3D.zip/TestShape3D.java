public class TestShape3D{
	public static void main(String [] args){
	
	Shape3D[] shapes = {new  Cube(), new RectangularPrism(), new Sphere(), new Cone()};
	
	for(int i=0; i<shapes.length; i++){
		//shapes[i].toString();
		System.out.println(shapes[i]);
	}
	
	}
}