public class Sphere  implements Shape3D{
	private static final double radius = 5;
	
	public double volume(){
		return (4/3.0)*Math.PI*radius*radius*radius;
	}
	
	public String toString(){
		return "volume: " + volume() + " This is a ball";
	}
}