public class Cone implements Shape3D{
	
	private double radius = 4;
	
	public double volume(){
		return (1/3.0)*Math.PI*radius*radius*radius;
	}
	
	public String toString(){
		return "volume: " + volume() + " This is a cone";
	}
}