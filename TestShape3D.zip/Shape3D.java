interface Shape3D{

	public String toString();
}