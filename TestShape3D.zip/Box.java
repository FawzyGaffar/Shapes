public class Box implements Shape3D{
	
	public final static int length = 10;
	public final static int width = 5;
	public final static int height = 6;
	
	
	
}