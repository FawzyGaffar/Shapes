public class Cube extends Box implements Shape3D{
	
	public double volume(){
		return length*length*length;
	}
	
	public String toString(){
		return "volume: " + volume() + " This is a box";
	}

}